package com.example.covid19cv;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ItemReportDetail extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_report);
        Intent receivedIntent = getIntent();
        String muniName = receivedIntent.getStringExtra("name");
        String description = receivedIntent.getStringExtra("description");

        setTitle(muniName + " Reports");
        TextView tb1 = findViewById(R.id.description);
        System.out.print(description);
        tb1.setText(description);
    }
}
